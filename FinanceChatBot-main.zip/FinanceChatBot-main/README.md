# FinanceChatBot
A Python-based tool for managing personal finances. It calculates budgets, summaries savings, and uses a conversational AI model to provide finance-related advice.
